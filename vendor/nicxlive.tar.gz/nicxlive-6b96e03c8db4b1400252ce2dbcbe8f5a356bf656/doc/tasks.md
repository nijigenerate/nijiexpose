﻿# nicxlive 移植タスク進捗

Status: `[ ]` todo, `[>]` in progress, `[x]` done, `[?]` blocked.

## レンダリング基盤（Projectable互換の前提）
- [x] R1: RenderGraph 相当の API を実装（dynamicComposite push/pop、applyMask、drawPart などのコマンドキュー）
- [x] R2: RenderBackend に MaskApply/DynamicComposite begin/end/playback を追加し、RenderCommandEmitter から呼び出せるようにする
- [x] R3: Offscreen テクスチャ/ステンシルの生成・破棄・再利用（Texture 管理と reuseCachedTextureThisFrame の裏付け）
- [x] R4: RenderContext への renderGraph/renderBackend 配線と frame 管理（currentDynamicCompositeFrame 等）
- [x] R5: Projectable/Composite の serialize/deserialize で textureOffset/オフスクリーン状態/maxBoundsStartFrame など固有フィールドを保存/復元する（D版写経。auto_resized だけでなく offscreenSurface/textureOffset/useMaxChildrenBounds/deferredChanged 等も含む）
- [x] R6: Render queue フレームワークの移植（`render/commands.d`, `command_emitter.d`, `graph_builder.d`, `scheduler.d`, `backends/queue/package.d` を C++ に写経）
  - [x] Q1: render/commands の各コマンド構造体と enum を C++ に写経（DrawPart/ApplyMask/Begin/EndDynamicComposite など）
  - [x] Q2: RenderCommandEmitter を写経（コマンド構築・キュー投入・frame begin/end 管理）
  - [x] Q3: RenderGraphBuilder/RenderScheduler を写経し、queue backend にフック（frame 内の command list 構築）
  - [x] Q4: backend_queue を写経（queue 再生、render backend 呼び出し、resource handle 管理）
  - [x] Q5: immediate/render/profiler 等、queue依存の補助モジュールを必要に応じて写経し統合
    - [x] render/profiler: D 同等のスコープ計測＋1s毎のレポート
    - [x] render/immediate: inDrawTexture* 即時描画ラッパーを追加（Backend API 拡張）
    - [x] render/passes: RenderPassKind/RenderScopeHint を render_pass.hpp に写経済み（GraphBuilder で使用）
    - [x] render/shared_deform_buffer: SharedVecAtlas ベースの共有バッファ API を写経追加し Drawable/Part/Mask で利用開始
    - [x] Backend: differenceAggregation 系 API（DifferenceEvaluationRegion/Result）を RenderBackend/QueueBackend に追加（評価は未実装）
  - [x] File layout (D準拠で作成/分割): `core/render/commands.hpp/.cpp`, `command_emitter.hpp/.cpp`, `graph_builder.hpp/.cpp`, `scheduler.hpp/.cpp`, `backend_queue.hpp/.cpp`, `immediate.hpp/.cpp`, `profiler.hpp/.cpp`
- [>] R7: 2026-02 upstream 構成差分の追従（ファイル名レベル）
  - [ ] Q6: `core/render/backends/package.d` 相当の backend 選択/初期化層を `core/render/common.*`・`core/runtime_state.*`・`core/unity_native.*` に整理して明文化する
  - [ ] Q7: `core/render/tests/render_queue.d` 相当の回帰テスト（queue command 並び順、mask/dynamic composite）を nicxlive 側で追加する
  - [ ] U5: `integration/package.d` 相当の公開 API 集約レイヤを `core/unity_native.*` 周辺で定義する

## パラメータ / フィルタ基盤（優先）
- [x] P1: Vec2Array/InterpolateMode/gather・scatter など ParameterBinding が依存する utils を core/common に実装。
- [x] P2: ParameterBinding 詳細（Value/Deformation/ParameterParameterBinding の apply/scale/copy/swap/reverseAxis/reInterpolate 等）を D に合わせて移植。
- [x] P3: NodeFilter の `applyDeformToChildren` をフル実装（パラメータバインディングを辿って deform/transform を転送）。

## シリアライズ/フォーマット基盤（Unity DLL 前提）
- [>] F1: `fmt/package.d`, `fmt/io.d`, `fmt/serialize.d`, `fmt/binfmt.d` を写経し、C++の fmt モジュールを追加（InochiSerializer/Fghj 等を提供）【ヘッダ追加済み、INP テクスチャの TGA/PNG エンコードは未実装】
- [>] F2: fmt 基盤を使って Node/Puppet/Texture 等のシリアライズ経路を D 版と一致させる（ファイル読み書きは Unity 側バッファ渡しを前提。INP テクスチャセクション/EXT セクションは実装済、TGAのみ対応で PNG/BC7 未対応）

## ノード階層（基底 → 派生）
- [x] 1: `package.d` → `core/nodes/node.hpp/.cpp`（Node/TmpNode, TaskFlag/SerializeFlag/UUID/transform）
- [x] 2: `filter.d` → `core/nodes/filter.hpp`（NodeFilter/Mixin）
- [x] 3: `deformable.d` → `core/nodes/deformable.hpp`
- [>] 4: `drawable.d` → `core/nodes/drawable.hpp/.cpp`（shared buffer / welding / serialization）
- [>] 5: `part/package.d` → `core/nodes/part.hpp`
- [>] 6: `mask/package.d` → `core/nodes/mask.hpp`
- [x] 7: `composite/projectable.d` → `core/nodes/projectable.hpp`
- [x] 8: `composite/package.d` → `core/nodes/composite.hpp`
- [x] 9: `composite/dcomposite.d` → `core/nodes/dynamic_composite.hpp`
- [x] 10: `meshgroup/package.d` → `core/nodes/mesh_group.hpp`（パラメータ連動の deform 反映まで実装済）
- [x] 11: `deformer/base.d` → `core/nodes/deformer_base.hpp`
- [x] 12: `deformer/grid.d` → `core/nodes/grid_deformer.hpp`
- [>] 13: `deformer/path.d` → `core/nodes/path_deformer.hpp`
- [x] 14: `drivers/package.d` → `core/nodes/driver.hpp`
- [x] 15: `drivers/simplephysics.d` → `core/nodes/simple_physics_driver.hpp/.cpp`

### PathDeformer 追加タスク（写経・基盤整備）
- [x] PD1: driver シリアライズ/デシリアライズを D 同等に実装（physics ノードに type＋state を保存/復元）
- [x] PD2: diagnostics を D 同等に実装（begin/endDiagnosticFrame、invalid スナップショット／連続 invalid ログ）
- [x] PD3: deformChildren の最近点算出・tangent/normal 正規化・safeInverse のフォールバックを D と一致させる
- [x] PD4: applyDeformToChildren の診断フローを D に揃える（begin/endDiagnosticFrame、rebuffer 呼び出し位置など）

### ノード階層 1-13 行数トラッカー（◯/△/✗ 評価メモ）
| # | D (nijilive) | Lines | C++ (nicxlive) | Lines | 評価 |
| - | --- | ---:| --- | ---:| --- |
| 1 | nodes/package.d | 1466 | core/nodes/node.cpp | 1180 | ◯ |
| 2 | nodes/filter.d | 146 | core/nodes/filter.cpp | 65 | ◯ |
| 3 | nodes/deformable.d | 209 | core/nodes/deformable.cpp | 162 | ◯ |
| 4 | nodes/drawable.d | 740 | core/nodes/drawable.cpp | 829 | ◯ |
| 5 | nodes/part/package.d | 826 | core/nodes/part.cpp | 715 | ◯ |
| 6 | nodes/mask/package.d | 140 | core/nodes/mask.cpp | 49 | ◯ |
| 7 | nodes/composite/projectable.d | 1229 | core/nodes/projectable.cpp | 779 | ◯ |
| 8 | nodes/composite/package.d | 334 | core/nodes/composite.cpp | 229 | ◯ |
| 9 | nodes/composite/dcomposite.d | 41 | core/nodes/dynamic_composite.cpp | 15 | ◯ |
| 10 | nodes/meshgroup/package.d | 611 | core/nodes/mesh_group.cpp | 562 | ◯ |
| 11 | nodes/deformer/base.d | 16 | core/nodes/deformer_base.hpp | 33 | ◯ |
| 12 | nodes/deformer/grid.d | 774 | core/nodes/grid_deformer.cpp | 620 | ◯ |
| 13 | nodes/deformer/path.d | 1334 | core/nodes/path_deformer.cpp | 1279 | △ |
| 14 | nodes/drivers/package.d | 58 | core/nodes/driver.hpp | 39 | ◯ |
| 15 | nodes/drivers/simplephysics.d | 1003 | core/nodes/simple_physics_driver.cpp | 781 | ◯ |

※ 写経レベルの突合前の暫定値。メソッド/フィールドごとの差分列挙と検証後、◯になるまで更新する。

### レンダリング層 行数トラッカー（◯/△/✗ 評価メモ）
| # | D (nijilive) | Lines | C++ (nicxlive) | Lines | 評価 |
| - | --- | ---:| --- | ---:| --- |
| RQ1 | render/commands.d | 162 | core/render/commands.cpp | 99 | ◯ |
| RQ2 | render/command_emitter.d | 23 | core/render/command_emitter.cpp | 197 | ◯ |
| RQ3 | render/graph_builder.d | 230 | core/render/graph_builder.cpp | 185 | ◯ |
| RQ4 | render/scheduler.d | 84 | core/render/scheduler.cpp | 35 | ◯ |
| RQ5 | render/shared_deform_buffer.d | 200 | core/render/shared_deform_buffer.cpp | 191 | △ |
| RQ6 | render/immediate.d | 38 | core/render/immediate.cpp | 22 | ◯ |
| RQ7 | render/passes.d | 34 | core/render/render_pass.hpp | 14 | ◯ |
| RQ8 | render/profiler.d | 99 | core/render/profiler.cpp | 93 | ◯ |
| RQ9 | render/backends/queue/package.d | 422 | core/render/backend_queue.cpp | 214 | △ |
| RQ9b | render/backends/package.d | 182 | （未移植） | 0 | ✗ |
| RQ9c | render/tests/render_queue.d | 345 | （未移植） | 0 | ✗ |
| RQ10 | render/backends/opengl/* | 4150 | （未移植） | 0 | ✗ |
| RQ11 | render/backends/directx12/* | 2915 | （未移植） | 0 | ✗ |

### fmt 層 行数トラッカー（◯/△/✗ 評価メモ）※上記 F1/F2 タスク対応
| Task ID | D モジュール | Lines | C++ モジュール | Lines | 評価 |
| - | --- | ---:| --- | ---:| --- |
| F1 (fmt/package) | fmt/package.d | 37 | fmt/fmt.hpp | 73 | △ |
| F1 (fmt/io) | fmt/io.d | 118 | fmt/io.hpp | 44 | ◯ |
| F1 (fmt/serialize) | fmt/serialize.d | 185 | fmt/serialize.hpp | 48 | ◯ |
| F1 (fmt/binfmt) | fmt/binfmt.d | 81 | fmt/binfmt.hpp | 37 | ◯ |

※ バックエンドは queue のみ移植済み。OpenGL/DX12 系は未着手のため ✗。人数の差は写経範囲の差異を示す。

### Unity Native DLL exports（DllImport 参照）
- [x] U1: `njgCreateRenderer`/`njgDestroyRenderer`/`njgFlushCommandBuffer`/`njgGetGcHeapSize`/`njgGetTextureStats` の C API を `extern "C"` で実装し、構造体 packing 含め D 版と一致させる（`unity-managed/Interop/NijiliveNative.cs` に準拠）※ GC サイズは malloc 統計の概算
- [x] U2: `njgLoadPuppet`/`njgUnloadPuppet`/`njgBeginFrame`/`njgTickPuppet` を写経ベースで C API 化（`njgLoadPuppetFromMemory`/`njgWritePuppetToMemory`/`njgFreeBuffer` は D に存在しないため削除）
- [x] U3: `njgEmitCommands`/`njgGetSharedBuffers` で queue/backend のコマンドと共有バッファスナップショットを返す C API を実装（SharedBufferSnapshot に頂点/UV/deform のポインタ＋長さを詰める）
- [x] U4: `njgGetParameters`/`njgUpdateParameters` のパラメータ列挙・更新 API を写経し、構造体サイズ/packing を D 版に揃える（P/Invoke バッファ経由）
- [ ] U5: `integration/package.d` のエントリ集約方針を C++ 側に反映（Unity Native API の公開境界を `core/unity_native.*` で明示化）

## compat 差分由来の実装タスク（全件）

判定基準: D実装を正とし、`✗（未実装）`は実装タスク、`✗（削除候補）`は削除またはD側準拠に寄せるタスク、`△`は挙動差分解消タスクとして扱う。

Status: `[ ]` todo, `[>]` in progress, `[x]` done, `[?]` blocked.

| Status | Task ID | 種別 | 参照 | 対象項目 | 結果 | 実装方針 |
| --- | --- | --- | --- | --- | --- | --- |
| [x] | CP001 | missing_impl | `compat-binding.md` | `deserializeFromFghj` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP002 | missing_impl | `compat-binding.md` | `finalize` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP003 | behavior_diff | `compat-binding.md` | `getNodeUUID` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP004 | behavior_diff | `compat-binding.md` | `isCompatibleWithNode` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP005 | missing_impl | `compat-binding.md` | `reconstruct` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP006 | missing_impl | `compat-binding.md` | `serializeSelf` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP007 | behavior_diff | `compat-binding.md` | フィールド `BindTarget.target` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP008 | behavior_diff | `compat-command_emitter.md` | `beginMask(bool useStencil)` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP009 | behavior_diff | `compat-command_emitter.md` | `drawPart(Part, bool)` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP010 | behavior_diff | `compat-command_emitter.md` | `endMask()` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP011 | remove_candidate | `compat-command_emitter.md` | `QueueCommandEmitter::backendQueue()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP012 | remove_candidate | `compat-command_emitter.md` | `QueueCommandEmitter::playback(RenderBackend*)` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP013 | remove_candidate | `compat-command_emitter.md` | `QueueCommandEmitter::queue() const` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP014 | remove_candidate | `compat-command_emitter.md` | `QueueCommandEmitter::record(...)` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP015 | remove_candidate | `compat-command_emitter.md` | `QueueCommandEmitter::recorded() const` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP016 | remove_candidate | `compat-command_emitter.md` | `RenderQueue::ready()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP017 | behavior_diff | `compat-command_emitter.md` | フィールド `QueueCommandEmitter.activeBackend_` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP018 | behavior_diff | `compat-command_emitter.md` | フィールド `RenderQueue.activeBackend_` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP019 | behavior_diff | `compat-command_emitter.md` | フィールド `RenderQueue.frameState_` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP020 | behavior_diff | `compat-fmt.md` | `inIsINPMode` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP021 | missing_impl | `compat-fmt.md` | `inLoadPuppet(string file)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP022 | behavior_diff | `compat-fmt.md` | `inWriteINPPuppet(Puppet, string file)` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP023 | behavior_diff | `compat-fmt.md` | `inWriteINPPuppetMemory(Puppet)` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP024 | behavior_diff | `compat-path_deformer.md` | フィールド `diagnostics` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP025 | remove_candidate | `compat-render-common.md` | class `RenderCommandEmitter.playback` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP026 | missing_impl | `compat-runtime_state.md` | currentRenderBackend | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP027 | missing_impl | `compat-runtime_state.md` | difference aggregation API | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP028 | missing_impl | `compat-runtime_state.md` | inDumpViewport | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP029 | missing_impl | `compat-runtime_state.md` | inEnsureCameraStackForTests | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP030 | missing_impl | `compat-runtime_state.md` | inEnsureViewportForTests | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP031 | missing_impl | `compat-runtime_state.md` | inGetClearColor | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP032 | behavior_diff | `compat-runtime_state.md` | inGetViewport | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP033 | missing_impl | `compat-runtime_state.md` | initRenderer | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP034 | missing_impl | `compat-runtime_state.md` | initRendererCommon | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP035 | missing_impl | `compat-runtime_state.md` | inSetClearColor | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP036 | behavior_diff | `compat-runtime_state.md` | inSetViewport | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP037 | missing_impl | `compat-runtime_state.md` | inViewportDataLength | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP038 | missing_impl | `compat-runtime_state.md` | render target handles (inGetRenderImage 等) | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP039 | missing_impl | `compat-runtime_state.md` | requireRenderBackend | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP040 | missing_impl | `compat-runtime_state.md` | tryRenderBackend | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP041 | remove_candidate | `compat-scheduler.md` | `RenderContext.frameId` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP042 | behavior_diff | `compat-scheduler.md` | `RenderContext.renderBackend` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP043 | behavior_diff | `compat-serialize.md` | IDeserializable | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP044 | behavior_diff | `compat-serialize.md` | Ignore | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP045 | behavior_diff | `compat-serialize.md` | ISerializable | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP046 | behavior_diff | `compat-serialize.md` | Name | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP047 | behavior_diff | `compat-serialize.md` | Optional | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP048 | missing_impl | `compat-texture.md` | lock | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP049 | missing_impl | `compat-texture.md` | unlock | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP050 | behavior_diff | `compat-timing.md` | `inInit(timeFunc)` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP051 | behavior_diff | `compat-transform.md` | `calcOffset(Transform other)` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP052 | missing_impl | `compat-transform.md` | `toString()` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP053 | missing_impl | `compat-transform.md` | deserializeFromFghj() | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP054 | missing_impl | `compat-transform.md` | serialize() | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP055 | behavior_diff | `compat-transform.md` | フィールド `scale` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP056 | missing_impl | `compat-triangle.md` | `calcOffsetInTriangleCoords(vec2, MeshData&, int[] triangle)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP057 | missing_impl | `compat-triangle.md` | `findSurroundingTriangle(vec2, MeshData&)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP058 | missing_impl | `compat-triangle.md` | `isPointInTriangle(vec2, Vec2Array)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP059 | missing_impl | `compat-triangle.md` | `nlCalculateTransformInTriangle(Vec2Array, int[] triangle, Vec2Array deform, vec2 target, out vec2 target_prime, out float rotVert, out float rotHorz)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP060 | missing_impl | `compat-triangle.md` | `private: applyAffineTransform(mat3, vec2)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP061 | missing_impl | `compat-triangle.md` | `private: calculateAffineTransform(Vec2Array, int[] triangle, Vec2Array deform)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP062 | missing_impl | `compat-triangle.md` | `private: calculateAngle(vec2, vec2)` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP063 | behavior_diff | `compat-unity_native.md` | `njgFlushCommandBuffer` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP064 | remove_candidate | `compat-unity_native.md` | `njgFreeBuffer` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP065 | behavior_diff | `compat-unity_native.md` | `njgGetGcHeapSize` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP066 | missing_impl | `compat-unity_native.md` | `njgGetPuppetExtData` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP067 | missing_impl | `compat-unity_native.md` | `njgGetRenderTargets` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP068 | missing_impl | `compat-unity_native.md` | `njgGetSharedBuffers` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP069 | remove_candidate | `compat-unity_native.md` | `njgLoadPuppetFromMemory` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [>] | CP070 | missing_impl | `compat-unity_native.md` | `njgPauseAnimation` | C API 枠のみ、D本体ロジック未写経 | D実装をC++へ移植（未実装の解消） |
| [>] | CP071 | missing_impl | `compat-unity_native.md` | `njgPlayAnimation` | C API 枠のみ、D本体ロジック未写経 | D実装をC++へ移植（未実装の解消） |
| [x] | CP072 | missing_impl | `compat-unity_native.md` | `NjgRenderTargets` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP073 | missing_impl | `compat-unity_native.md` | `njgRuntimeInit` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP074 | missing_impl | `compat-unity_native.md` | `njgRuntimeTerm` | - | D実装をC++へ移植（未実装の解消） |
| [>] | CP075 | missing_impl | `compat-unity_native.md` | `njgSeekAnimation` | C API 枠のみ、D本体ロジック未写経 | D実装をC++へ移植（未実装の解消） |
| [x] | CP076 | missing_impl | `compat-unity_native.md` | `njgSetLogCallback` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP077 | missing_impl | `compat-unity_native.md` | `njgSetPuppetScale` | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP078 | missing_impl | `compat-unity_native.md` | `njgSetPuppetTranslation` | - | D実装をC++へ移植（未実装の解消） |
| [>] | CP079 | missing_impl | `compat-unity_native.md` | `njgStopAnimation` | C API 枠のみ、D本体ロジック未写経 | D実装をC++へ移植（未実装の解消） |
| [x] | CP080 | remove_candidate | `compat-unity_native.md` | `njgWritePuppetToMemory` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [>] | CP081 | missing_impl | `compat-vec2array.md` | SIMD対応 (`applySIMD` 等) | 未着手（スカラ経路で暫定動作） | D実装をC++へ移植（未実装の解消） |
| [x] | CP082 | behavior_diff | `compat-vec2array.md` | フィールド `alignment` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP083 | behavior_diff | `compat-vec2array.md` | フィールド `backing` | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP084 | behavior_diff | `compat-vec2array.md` | フィールド `lanes` (x,y SoA) | - | D実装の挙動に合わせて差分を解消 |
| [x] | CP085 | missing_impl | `compat-vec2array.md` | 単体テスト | - | D実装をC++へ移植（未実装の解消） |
| [x] | CP086 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::playback(RenderBackend*)` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP087 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::recorded()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP088 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::backendQueue()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP089 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::backendResourceQueue()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP090 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::clearResourceQueue()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP091 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::renderTarget()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP092 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::compositeTarget()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP093 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedVerticesRaw()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP094 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedUvRaw()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP095 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedDeformRaw()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP096 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedVertexCount()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP097 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedUvCount()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP098 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedDeformCount()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP099 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedVerticesData()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP100 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedUvData()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP101 | remove_candidate | `compat-queue.md` | `QueueRenderBackend::sharedDeformData()` | - | C++独自実装を削除、またはD側に寄せて一本化 |
| [x] | CP102 | behavior_diff | `compat-unity_native.md` | `njgTickPuppet` ABI (`float` vs `double`) | - | D準拠で `double deltaSeconds` に修正 |
| [x] | CP103 | behavior_diff | `compat-unity_native.md` | `njgEmitCommands` ABI (`SharedBufferSnapshot* + const CommandQueueView**` vs `CommandQueueView*`) | - | D準拠で `CommandQueueView* outView` に修正し、shared は `njgGetSharedBuffers` へ分離 |
| [x] | CP104 | behavior_diff | `compat-unity_native.md` | `NjgRenderCommandKind` 列挙値順（`DrawMask` 欠落） | - | `DrawMask/BeginComposite/DrawCompositeQuad/EndComposite` を含む D 準拠順へ修正 |
| [x] | CP105 | behavior_diff | `compat-unity_native.md` | `NjgPartDrawPacket` レイアウト（`renderMatrix`/`renderRotation` 欠落） | - | D 準拠レイアウトへ修正、queue 詰め替えを更新 |
| [x] | CP106 | behavior_diff | `compat-unity_native.md` | `NjgDynamicCompositePass` レイアウト（`autoScaled`/`drawBufferCount`/`hasStencil` 欠落） | - | D 準拠レイアウトへ修正、queue 詰め替えを更新 |
| [x] | CP107 | behavior_diff | `compat-unity_native.md` | `CommandQueueView.commands` 型不一致（`const void*`） | - | D 準拠で `const NjgQueuedCommand*` へ修正 |
| [x] | CP109 | behavior_diff | `compat-unity_native.md` | `MaskDrawableKind` 列挙値（内部 `Part/Drawable/Mask` を export） | - | D 準拠で export は `Part/Mask` の2値へ修正 |
| [x] | CP108 | behavior_diff | `compat-unity_native.md` | `nijiv-opengl --test` で `0xC0000409` (BEX64) | - | `njgLoadPuppet` 例外未捕捉を C API 境界で捕捉し `Failure` 返却へ修正、原因切り分け可能化 |
| [x] | CP110 | behavior_diff | `compat-binfmt.md` | `MAGIC_BYTES`/`TEX_SECTION`/`EXT_SECTION` 定数不一致（`INOCHI02` 系） | - | D準拠 `TRNSRTS\\0` / `TEX_SECT` / `EXT_SECT` へ修正し `.inx` 読み込みを復旧 |
| [x] | CP111 | behavior_diff | `compat-vec2array.md` | `Vec2Array/Vec3Array/Vec4Array` の copy semantics（浅いポインタコピー） | - | D準拠の値型動作に修正（copy ctor/copy assign で実データ複製、内部ポインタ再同期） |
| [x] | CP112 | behavior_diff | `compat-vec2array.md` | `copyFrom` 初期化漏れ（`logicalLength_` 未リセットで `ensureLength` 早期 return） | - | `logicalLength_=0` を含む完全初期化へ修正し、`nijiv --test` の AV (`0xC0000005`) を解消 |
| [x] | CP113 | missing_impl | `compat-path_deformer.md` | `deform(Vec2Array)` | - | D準拠で `deformedCurve = createCurve(...)` を実装し、`applyPathDeform` から呼び出すよう修正 |
| [x] | CP114 | behavior_diff | `compat-path_deformer.md` | `applyPathDeform` の driver 初期化 (`setup` vs `updateDefaultShape`) | - | D準拠で初回初期化を `driver.setup()` に統一 |
| [x] | CP115 | behavior_diff | `compat-path_deformer.md` | `applyDeformToChildren` 終端処理 | - | D準拠で `physicsOnly = true` 後に `rebuffer(empty)` を実施 |
| [x] | CP116 | behavior_diff | `compat-deformable.md` | `preProcess/postProcess` と `DeformationStack` の更新順 | - | D準拠で stack/filter の更新順と shared deform dirty 反映を一致化 |
| [x] | CP117 | behavior_diff | `compat-node.md` | `FilterHook` 同一性管理 | - | Dの `(stage,func)` 管理に対応するため C++側は `stage+tag` 管理へ統一し、登録/解除対称性を担保 |
| [x] | CP118 | behavior_diff | `compat-drawable.md` | node attach/weld hook 解除条件 | - | D準拠の重複回避/解除に合わせ、`stage+tag` で一意管理 |
| [x] | CP119 | behavior_diff | `compat-grid_deformer.md` | child filter 解除条件 | - | D準拠の登録/解除対称性に合わせ、`stage+tag` で一意管理 |
| [x] | CP120 | behavior_diff | `compat-meshgroup.md` | child filter 解除条件 | - | D準拠の登録/解除対称性に合わせ、`stage+tag` で一意管理 |
| [x] | CP121 | behavior_diff | `compat-vec2array.md` | `bindExternalStorage` と `x/y` 直接アクセスの整合性 | - | 先に `Vec2Array` の外部ビュー時アクセス規約を D 版へ写経し、`core/nodes/*`/`core/render/*` の直接 `x/y` 参照を規約準拠に統一してから `shared_deform_buffer` を D 同等（bindExternalStorage 使用）へ戻す |
| [x] | CP122 | behavior_diff | `compat-queue.md` | shared deform buffer の frame 間一貫性回帰 | `tools/check_shared_deform_consistency.sh` 追加、`vo=1947/2044` の `d0 range=0.0` を両系統で確認 | `nijiv --test ... --queue-dump` を nicxlive/nijilive で同条件比較し、`vo=1947/2044` を含む複数パーツの `d0` がフレーム間で発散しないことを完了条件として自動化/手順化 |
| [x] | CP123 | behavior_diff | `compat-drawable.md` | shared atlas producer 側の外部ビュー整合 (`core/nodes/drawable.cpp/.hpp`) | `vertices` 直登録へ移行、毎フレーム mirror copy/upload 経路を撤去済み | `Drawable` の atlas producer を D 準拠へ寄せ、`vertices` を直接 atlas 登録。`writeSharedBuffers` の毎フレームコピー/即時uploadを撤去し、`updateVertices/updateDeform` で dirty/resize 契約を統一 |
| [x] | CP124 | behavior_diff | `compat-part.md`, `compat-mask.md` | packet 生成側の atlas 参照整合 (`core/nodes/part.cpp`, `core/nodes/mask.cpp`) | `Part::updateUVs` を atlas 登録済み `sharedUvs` resize+反映へ修正済み | `Part::updateUVs` を D 準拠へ修正し、atlas 登録済み `sharedUvs` を resize+反映。`deformOffset/vertexOffset` と stride 参照契約を維持 |
| [>] | CP125 | behavior_diff | `compat-command_emitter.md` | shared buffer upload/hash 経路の外部ビュー整合 (`core/render/command_emitter.cpp`) | upload 条件は D 同等化済み、`HASH d` frame間固定差分が残存 | upload 条件を D 同等（dirty かつ length>0 のときのみ upload）に修正済み。`HASH d` 固定差分は継続調査 |
| [x] | CP126 | behavior_diff | `compat-unity_native.md` | Unity export/snapshot の外部ビュー整合 (`core/unity_native.cpp`) | `hashVec2Array` を `xAt/yAt` 化、shared 読み出しの生ポインタ依存を除去済み | `njgGetSharedBuffers` は D 同等に `rawStorage` + `vertex/uv/deformCount` を返却維持。関連読み出しは `xAt/yAt` ベースで統一（`hashVec2Array` を含む） |
| [x] | CP127 | behavior_diff | `compat-queue.md` | backend queue の shared buffer 保持整合 (`core/render/backend_queue.cpp/.hpp`) | `uploadShared*` の保持を `dup()` 固定化、alias/stale 参照を遮断済み | queue backend の shared buffer 保持を `dup()` に固定し、外部ビュー alias を遮断してフレーム間 stale 参照を防止 |
| [>] | CP128 | behavior_diff | `compat-deformable.md` | deformable 基盤の外部ビュー整合 (`core/nodes/deformable.cpp`) | `preUpdate` zero-fill 化と不要 dirty 除去は完了、`HASH d` 差分は未解消 | `DeformationStack::preUpdate` を D 同等の zero-fill のみに戻し、`updateDeform` の不要 dirty 強制を除去。frame間 deform hash 固定の残差分は継続調査 |
| [>] | CP129 | behavior_diff | `compat-grid_deformer.md`, `compat-path_deformer.md`, `compat-meshgroup.md` | deformer/filter 消費側の外部ビュー整合 | `GridDeformer` の写経差分を追加修正（`switchDynamic` を D 同等の毎回 `setupChildNoRecurse` に修正、`applyDeformToChildren` 冒頭の非D要素 `switchDynamic(false)` を削除、child deform 取得を `valueAt(point)` 直参照へ修正、`build` の余計な `refresh()` を削除、`trsBindings` 抽出を D 手順へ近づける更新を追加、`serializeSelfImpl` の flags 分岐を除去して D同様に常時書き込み化）。加えて `GridDeformer::deserializeFromFghj` の `formation` 読み取りを D準拠（文字列/数値対応）へ修正し、`Midori-gridtest2` の `Body` subtree 途中失敗を解消。`/tmp/run-midori-gridtest2-nicx-current.txt` で `emit out count=201`（修正前 193/167）を確認。 | `core/nodes/grid_deformer.cpp`, `core/nodes/path_deformer.cpp`, `core/nodes/mesh_group.cpp` の `x/y` 直接参照と `NodeFilterMixin` 手順差分を監査し、外部ビュー入力でも同値になるよう修正 |
| [>] | CP146 | behavior_diff | `compat-grid_deformer.md`, `compat-filter.md` | `GridDeformer::applyDeformToChildren` の `NodeFilterMixin._applyDeformToChildren` 完全写経 | `core/nodes/grid_deformer.cpp` を写経更新し、`transferChildren` 内 keypoint 算出・`transferCondition()` 呼び出し・node binding 更新順を D `filter.d` 手順へ一致化。`/tmp/run-midori-gridtest2-nicx-f1-cp146.txt` で build root DLL 読込と `emit out count=193` を確認。count差（nijilive 244/234 vs nicxlive 193/183）は未解消。 | 次は `deformChildren` の入出力比較ログを D/C++ 同条件で採取し、count 差の発生ノードを点単位で特定する。 |
| [x] | CP147 | behavior_diff | `compat-grid_deformer.md` | `GridDeformer::deformChildren` の早期return条件を D と一致化 | `core/nodes/grid_deformer.cpp:deformChildren` から `origDeformation.size()<origVertices.size()` 早期return と `cache.valid` invalidSamples 判定を除去し、D同様に非finiteのみ early return に修正。`/tmp/run-midori-gridtest2-nicx-f1-cp147.txt` で build root DLL 読込・実行完走（`emit out count=193`）を確認。 | count差（`nijilive 244/234` vs `nicxlive 193/183`）は別要因として継続。次は `deformChildren` 入出力の点単位比較ログを D/C++ 同条件で採取する。 |
| [x] | CP148 | behavior_diff | `compat-part.md`, `compat-command_emitter.md`, `compat-grid_deformer.md` | `ApplyMask` が `BeginMask` なしで出るコマンド列不整合（`Midori-gridtest2`） | `GridDeformer::deserializeFromFghj` の `formation` 文字列/数値対応を写経修正後も残っていた mask 欠落の根因を `Part::finalize` に特定。C++ が `super.finalize()` 相当を呼ばず Composite 配下 Part の `maskSrc` 解決が未実行だったため、`Part::finalize` 冒頭で `Drawable::finalize()` を呼ぶ D 写経修正を実施。`/tmp/queue-midori-gridtest2-maskfix-final-nicx-f1.log` で `DrawPart=156 / BeginMask=34 / ApplyMask=27 / EndMask=17` と `nijilive` 同数、`/tmp/run-midori-gridtest2-maskfix-final-nicx-f1.txt` で `emit out count=244` を確認。 | 完了。残差分は別タスク（deformation/path差分）へ切り分けて継続する。 |
| [x] | CP149 | behavior_diff | `compat-mask.md`, `compat-part.md` | `Mask` ノードのマスク適用行列と dodge 反映が D と不一致 | `core/nodes/mask.cpp` を写経修正し、`fillMaskDrawPacket` の `mvp` を D 同等（offscreen有効時 `offscreenRenderMatrix * model`、それ以外 `currentRenderSpace.matrix * model`）へ統一。`renderMask(bool dodge)` で `isDodge` を引数反映。`fillDrawPacket` の不要 geometry clear も撤去して D 契約へ一致。 | `Midori-20250426-1.6.2.inx` / `Midori-gridtest2-20250426-1.6.2.inx` で `Mask` ノード経由の `ApplyMask(kind=Mask)` を queue dump で再検証し、袖表示/マスク抜け症状との相関を継続確認する。 |
| [>] | CP130 | behavior_diff | `compat-binding.md`, `compat-parameter.md` | parameter/binding 側の Vec2Array 参照整合 | `Parameter::finalize` の valid 判定を D 同等へ修正済み、slot 操作監査を継続 | `core/param/parameter.hpp`, `core/param/binding_impl.hpp` の deformation slot 操作を監査し、外部ビュー前提でも破綻しないアクセス規約へ統一 |
| [>] | CP131 | behavior_diff | `compat-triangle.md`, `compat-common.md` | 幾何補助と曲線処理の Vec2Array 参照整合 | 対象の `x/y` 直接参照は置換済み、外部ビュー化後の計算一致を継続確認中 | `core/nodes/curve.cpp`, `core/nodes/deformer/drivers/phys.cpp`, `core/common/utils.hpp` 周辺の `x/y` 参照を監査し、外部ビュー化後の計算一致を確認 |
| [x] | CP132 | behavior_diff | `compat-unity_native.md`, `compat-composite.md` | Puppet scale 変更時の DynamicComposite `initTarget -> createTexture/updateTexture` 連鎖 | `unity_native` の DynamicComposite 外部ハンドル生成で `updateTexture` が空データ時に未呼び出しだった差分を修正し、`njiv` 実測で scale 変更時の Composite 再生成経路で callback 連鎖が発生することを確認 | `core/unity_native.cpp` の `ensureDynamicTextureHandle` を D 側契約に合わせ、`createTexture` 直後に常に `updateTexture` を呼ぶ（不足データは 0 埋め） |
| [x] | CP133 | behavior_diff | `compat-composite.md`, `compat-projectable.md` | Puppet scale 変化時の `Composite` 再初期化/再描画フロー | `Projectable::rebuffer` と `Composite::rebuffer` の写経欠落を修正し、`rebuffer -> initialized=false -> notifyChange` と `autoResizedMesh=true` 維持を追加。`NJIV_AUTO_WHEEL_INTERVAL=1, PHASE_TICKS=100, --frames 220`（`run-nicx-f220-buildroot-20260223.txt`）で `initTarget type=Composite` と `create h=... rt=true` のサイズが連続拡大することを確認。 | `nijilive` の `composite.d` / `projectable.d` と C++ 実装を関数単位で再比較し、Dに存在する契約のみを実装する |
| [x] | CP135 | behavior_diff | `compat-drawable.md`, `compat-projectable.md` | `Drawable::updateBounds` の座標系不一致で `initTarget` がスケール非反映サイズを使う | `core/nodes/drawable.cpp` を D写経で `getDynamicMatrix` ベースへ修正済み。`run-nicx-f220-buildroot-20260223.txt` では `initTarget type=Composite` が `tex=(91,81)` から `tex=(6106,5387)` まで拡大し、固定症状は解消。 | `nijilive/core/nodes/drawable.d:updateBounds` を正として、`nicxlive/core/nodes/drawable.cpp:updateBounds` を同等ロジックへ写経。`njiv --test` の大スケール操作で `initTarget tex=(...)` がスケール追従することを確認する。 |
| [x] | CP136 | behavior_diff | `compat-projectable.md`, `compat-composite.md` | C++独自 `Projectable::enqueueRenderCommands` が Composite専用経路を迂回する差分 | `core/nodes/projectable.cpp` の `Projectable::enqueueRenderCommands` を D写経方針で `Part::enqueueRenderCommands(ctx)` へ委譲化。`run-nicx-f220-buildroot-20260223.txt` で Begin/EndDynamicComposite と内部 DrawPart が継続して発行され、拡大時も経路が維持されることを確認。 | D側には `Projectable::enqueueRenderCommands` 独自実装がないため、C++独自 push/pop 実装を排除して基底挙動へ寄せる。次は `Composite::createSimpleMesh/getChildrenBounds/compositeAutoScale` の実呼び出し経路を D と関数単位で再突合して継続。 |
| [x] | CP137 | behavior_diff | `compat-drawable.md` | `inSetUpdateBounds` の引数処理差分（Dは常時有効化） | `core/nodes/drawable.cpp` の `inSetUpdateBounds(bool)` を D準拠で `state` 無視・`true` 固定へ修正済み。`run-nicx-f220-buildroot-20260223.txt` で Composite RT サイズが拡大追従することを確認。 | D実装 `drawable.d` を正として API契約を一致させる。次段では `Composite` スケール値算出が実際に `initTarget` へ反映される呼び出しチェーンを追跡する。 |
| [x] | CP138 | behavior_diff | `compat-projectable.md` | `Projectable::initTarget` のテクスチャサイズ算出差分（C++は world bounds、Dは local vertices+deformation） | `core/nodes/projectable.cpp:initTarget` を D写経で修正し、`texWidth/texHeight` を `vertices + deformation` ローカル min/max から算出。`run-nicx-f220-buildroot-20260223.txt` で Composite の `initTarget` サイズが連続増加することを確認。 | `nijilive/core/nodes/composite/projectable.d:initTarget` を正として、同一アルゴリズムへ写経。`NJIV_AUTO_WHEEL` 条件で `initTarget type=Composite` の `tex=(...)` がスケール拡大時に追従するかを確認する。 |
| [x] | CP139 | behavior_diff | `compat-puppet.md`, `compat-projectable.md` | `Puppet` デシリアライズ後の `scanParts/selfSort` 契約不足で Composite 経路が不安定 | D版 `Puppet.finalize` 準拠で `scanParts(true, root)` と `selfSort()` を追記済み。`run-nicx-f220-buildroot-20260223.txt` で Composite 再生成と描画経路が安定継続することを確認。 | `nijilive/core/puppet.d:finalize` を正として、`nicxlive/core/puppet.cpp:deserializeFromFghj` の末尾に `scanParts(true, root)` + `selfSort()` を写経。`NJIV_AUTO_WHEEL` で `Composite` RT サイズが拡大追従するかを確認する。 |
| [x] | CP140 | behavior_diff | `compat-command_emitter.md` | `EndDynamicComposite` の `origViewport` が begin 時値を保持せず 1280x720 に戻る差分 | `core/render/command_emitter.cpp:endDynamicComposite` を写経修正し、`dynStack` から取り出した pass を `EndDynamicComposite` に詰めるよう変更。`queue-midori-nicx-f1-20260223k.log` で `CMD 206/225` の `ovp` が `nijilive` と同じ `234x161` / `232x159` に一致。 | D `render/backends/queue/package.d:endDynamicComposite` と同じく、開始時に確定した passData を終了コマンドへ引き継ぐ。 |
| [>] | CP141 | behavior_diff | `compat-path_deformer.md` | Midori の `Upper Leg::*::PD` / `Lower Leg::*` で `d0` が過大（袖非表示の主因候補） | `PathDeformer::deformChildren` の D差分（offsetゼロ時に `changed=false` 早期 return）を写経修正し、`/tmp/queue-midori-nicx-aftercp145.log` で `avgAbsDx=0.948`（修正前 `/tmp/queue-midori-nicx-current.log` は `4.685`）、`gt10=4`（修正前 `19`）まで改善。特に `do=7737/7892/8086` は `|d0|≈40` 台から `≈0~2` 台へ縮小。 | 残差分（`do=7515/7546/7921/7951` が `|d0|≈10~14`）は継続。次は `deformer/path.d:deformChildren` の `centerMatrix` 後段（`target.notifyChange` 含む返却契約）と `drivers/phys.d:update` の更新順を関数単位で再写経し、`/tmp/queue-midori-niji-current.log` との差分をさらに詰める。 |
| [>] | CP145 | behavior_diff | `compat-part.md`, `compat-node.md`, `compat-unity_native.md` | Midori でマスク適用列が崩れ、`nijilive` の `ApplyMask` が `nicxlive` では `EndMask` 化する箇所がある（袖問題と独立した根本候補） | `core/nodes/part.cpp` で `mask_mode` / `masks[].mode` の文字列デシリアライズ（`DodgeMask`）欠落を修正し、`core/nodes/mask.cpp` で Mask IBO の queue backend 同期を追加。`/tmp/queue-midori-nicx-postfix.log` と `/tmp/queue-midori-niji-maskih.log` で `CMD 111..120` が一致（`usesStencil=0`, `ApplyMask mk=1 dodge=1`, `mask(v=10/20 i=30/72)`）。 | マスク列は一致したので、残る袖非表示は `PathDeformer` 差分側（`do=7515/7546/7921/7951`）を優先して継続する。 |
| [x] | CP140 | behavior_diff | `compat-unity_native.md` | `nijiv` が古い `nicxlive` DLL を優先解決し、検証結果が最新実装を反映しない | `nijiv/source/app.d` の nicxlive DLL 探索順を修正（Windows: `Debug/RelWithDebInfo/Release/build root`、macOS/Linux: `build root` 優先）し、`run-nicx-f1-pathcheck-20260223.txt` / `run-nicx-f220-buildroot-20260223.txt` で `path=.../nicxlive/build/libnicxlive.dylib` を確認。 | `nijiv` 側の DLL 解決順を更新し、`doc/how-to-debug.md` の手順も同順へ修正。以後はコピーなしで「直近ビルド成果物」を直接検証する。 |
| [x] | CP141 | behavior_diff | `compat-part.md`, `compat-composite.md` | Begin/EndDynamicComposite 区間の Albedo 黒化（根因: `tint=(0,0,0)`） | 現象は解消。根因は tint 0化であることを確認済み。再発防止として `Part::fillDrawPacket` の tint/screenTint 計算を D 同様に NaN ガード付きへ修正し、`run-nicx-f1-tintguard-20260223.txt` で build root DLL 読込・描画完走（`emit out count=210`）を確認。 | `nijilive/core/nodes/part/package.d:fillDrawPacket` を正として、`nicxlive/core/nodes/part.cpp:fillDrawPacket` の tint/screenTint クランプを写経し、offset 異常値で tint が 0/NaN 汚染しないようにする。 |
| [x] | CP142 | behavior_diff | `compat-meshgroup.md`, `compat-path_deformer.md` | `MeshGroup::filterChildren` が `PathDeformer` を `renderEnabled` で判定しており D と不一致 | `core/nodes/mesh_group.cpp` を修正し、D準拠で `PathDeformer` の driver 有無（`_driver !is null` 相当）で判定するよう統一。写経外の一時ログも削除。 | `nijilive/core/nodes/meshgroup/package.d:filterChildren` を正として `if (auto pathDeformer = cast(PathDeformer)deformer) if (!pathDeformer.physicsEnabled) return` の契約へ合わせる。 |
| [x] | CP143 | behavior_diff | `compat-path_deformer.md` | `PathDeformer` デシリアライズが D の `vertices` ではなく C++ 独自 `controlPoints` 優先で読まれ、曲線情報を取りこぼす | `core/nodes/path_deformer.cpp` を修正し、D準拠で `vertices` 連続値を最優先で読み取り、`curve_type/curveType/physicsType` を文字列・数値の両方で復元するよう修正。`/tmp/queue-midori162-nicx-f120-after-enumfix.log` で `FRAME 0 count=244`（修正前146）と frame毎の `HASH d` 変化を確認。 | `nijilive/core/nodes/deformer/path.d:deserializeFromFghj` を正として、`vertices`→`rebuffer`→`physics` 復元順を維持し、enum復元も D互換で吸収する。 |
| [x] | CP144 | behavior_diff | `compat-drawable.md`, `compat-part.md`, `compat-meshgroup.md` | UV atlas が D と不一致（`nicxlive: uvs=8816` / `nijilive: uvs=7880`、`DrawPart` の `uo==vo` 固定化） | `Drawable::updateVertices` から UV atlas 更新を除去し、D同様に `rebuffer`/`Part::updateUVs` 経由へ責務を戻した。併せて `Part::deserializeFromFghj` に `updateUVs()` を追加し、`MeshGroup::rebuffer` を `Drawable::rebufferMesh` 経由へ修正。`/tmp/qdump_midori_nicx_after_uvsync.txt` で `FRAME 0 count=244 vertices=8816 uvs=7880` と `uo` 差分（例: `vo=7248 uo=6312`）が D と一致。 | `nijilive/core/nodes/drawable.d:updateVertices`, `nijilive/core/nodes/drawable.d:rebuffer`, `nijilive/core/nodes/part/package.d:deserializeFromFghj/updateUVs`, `nijilive/core/nodes/meshgroup/package.d:rebuffer` を正として、UV atlas 更新の呼び出し点を写経準拠へ統一する。 |
| [x] | CP150 | behavior_diff | `compat-webgl_backend.md` | `opengl_backend.d` と `webgl_backend.js` の関数対応表作成 | `doc/compat-webgl_backend.md` を追加し、コマンド再生・mask・dynamic composite・shader stage・MRT・拡張機能まで対応表を作成済み。 | D実装を正として、各関数の実装有無と差分種別（◯/△/✗）を継続更新する。 |
| [x] | CP151 | missing_impl | `compat-webgl_backend.md` | shader stage分離（`partShaderStage1/2/3`）とMRT (`drawBuffers`) | `webgl_backend.js` で `partShaderStage1/2/3` を分離し、`setupShaderStage` に stage別 `setDrawBuffersSafe(1/2/3)` を写経実装。`createDynamicCompositePass` も color attachment 0..2 を接続する構成へ更新。 | `opengl_backend.d` の `setupShaderStage` / `setDrawBuffersSafe` / `createDynamicCompositePass` を正として、WebGL2で可能な範囲のMRT構成へ寄せる。 |
| [x] | CP152 | missing_impl | `compat-webgl_backend.md` | dynamic composite の stencil attachment と mask 統合 | `webgl_backend.js` で `createTexture(stencil=true)` を `DEPTH24_STENCIL8` 生成に変更し、`createDynamicCompositePass` で `STENCIL_ATTACHMENT` 接続を追加。`beginMask` / `applyMask` / `beginMaskContent` / `endMask` は D のステンシル契約に合わせた順序へ維持。 | `opengl_backend.d` の `beginDynamicComposite` と `beginMask/applyMask` 契約を正として、offscreen stencil 付き mask 経路を WebGL2 で再現する。 |
| [x] | CP153 | missing_impl | `compat-webgl_backend.md` | post process / debug draw 系 (`postProcessScene`, thumbnail, debug points/lines) | `webgl_backend.js` に `postProcessingStack` 実行（scene quad）、`uploadDebugBuffer`、`drawDebugPoints`、`drawDebugLines`、`renderThumbnailGrid`（有効化フラグ付き）を追加。 | D側 `postProcessScene/renderScene` と `opengl_thumb.d` を正として、WebGL2で実行可能な debug/postprocess 経路を写経実装した。 |
| [x] | CP154 | behavior_diff | `compat-webgl_backend.md` | `postProcessScene` の default framebuffer 経路の完全一致 | 初期の中間FBOコピー経路から再写経し、`fBuffer/cfBuffer` を使う ping-pong + 最終 `blitFramebuffer` に切替。`postProcessScene` 後に `fBuffer` 側へ結果が戻る契約へ更新。 | D 側 `postProcessScene` の `fBuffer/cfBuffer` 二重バッファ契約を正として、WebGL2で可能な同型フローへ寄せる。 |
| [x] | CP155 | missing_impl | `compat-webgl_backend.md` | `presentSceneToBackbuffer` の写経不足（present shader/color key） | `webgl_backend.js` に `ensurePresentProgram` 相当（present shader + quad VAO/VBO + `srcTex/useColorKey` uniform）を写経実装し、`presentSceneToBackbuffer` で backbuffer clear 後に full-screen draw を実装。提示入力を `fAlbedo` 固定へ更新。 | `opengl_backend.d:presentSceneToBackbuffer/ensurePresentProgram` を正として、present shader 契約（color key含む）を一致させる。 |
| [x] | CP156 | behavior_diff | `compat-webgl_backend.md` | `beginScene/endScene` の MRT/FBO state 契約差分 | `fBuffer/cfBuffer` と `fAlbedo..cfStencil` の scene MRT ターゲットを導入し、`rebindActiveTargets` と `beginScene/endScene` の接続・clear・drawBuffers 復帰を写経実装。 | `opengl_backend.d:beginScene/endScene/rebindActiveTargets` 契約へ整合。default framebuffer の drawBuffers は WebGL2 制約に合わせ `BACK` を使用。 |
| [x] | CP157 | missing_impl | `compat-webgl_backend.md` | texture parameter API 群 (`applyTextureFiltering` など) | `webgl_backend.js` に `bindTextureHandle/uploadTextureData/generateTextureMipmap/applyTextureFiltering/applyTextureWrapping/applyTextureAnisotropy/readTextureData` を追加。`readTextureData` は WebGL2 制約に合わせて FBO + `readPixels` で実装。 | D 側 API 群を写経実装した。`ClampToBorder` / `glGetTexImage` など desktop GL 固有挙動は WebGL2 相当へフォールバックして扱う。 |
| [x] | CP158 | missing_impl | `compat-webgl_backend.md` | backend utility API (`framebufferHandle`, `rebindActiveTargets`, viewport stack, shader handle API) | `webgl_backend.js` に `framebufferHandle`（`fBuffer`返却）、`pushViewport/popViewport/getViewport`、`createShader/useShader/destroyShader/getShaderUniformLocation/setShaderUniform` と型別ラッパ、`rebindActiveTargets`（`f/cf` 再接続）を実装。 | D 側 utility API 契約に合わせ、主要公開面を写経実装した。 |
| [x] | CP159 | missing_impl | `compat-webgl_backend.md` | advanced blend 方程式 (`setAdvancedBlendEquation`) | `KHR_blend_equation_advanced(_coherent)` 検出、`setAdvancedBlendEquation` の拡張定数経路、`issueBlendBarrier -> blendBarrierKHR` 経路を追加。未対応環境は D と同様に legacy/no-op fallback。 | D 側 `setAdvancedBlendEquation` / `blendModeBarrier` 契約に沿って写経実装した。 |
| [x] | CP160 | behavior_diff | `compat-webgl_backend.md` | dynamic composite の `origBuffer/origViewport` 復帰契約 | `beginDynamicComposite` の `origBuffer` を `DRAW_FRAMEBUFFER_BINDING` 基準へ修正し、`endDynamicComposite` で `rebindActiveTargets` 後に `DRAW/READ_FRAMEBUFFER` 双方を `origBuffer` へ復帰する写経更新を実施。 | `opengl_backend.d:beginDynamicComposite/endDynamicComposite` 契約へ写経整合した。 |
| [x] | CP161 | behavior_diff | `compat-webgl_backend.md` | `postProcessScene` の `renderScene` 入力（area/mvp/fbSize/ambient） | `webgl_backend.js` の postprocess 描画に `area` ベース頂点更新、`ambientLight` / `fbSize` / `mvp` uniform 供給を追加し、`fBuffer/cfBuffer` ping-pong + `blitFramebuffer` へ整合。 | `opengl_backend.d:renderScene/postProcessScene` を正として写経実装した。 |
| [>] | CP162 | behavior_diff | `compat-webgl_backend.md` | texture parameter APIs の残差分（ClampToBorder, readback） | `CP157` で API は実装済み。さらに `EXT_texture_border_clamp` 対応を追加し、対応環境では `ClampToBorder` と border color(0,0,0,0) を反映。未対応環境は `CLAMP_TO_EDGE` フォールバック。 | WebGL2 非対応仕様（desktop GL依存）について、実行環境ごとの差分（extension有無）を明示し、運用方針を確定する。 |
| [ ] | CP134 | behavior_diff | `compat-unity_native.md`, `compat-projectable.md` | `njgSetPuppetScale`/`njgSetPuppetTranslation` 後の再描画トリガ | 追加していた `NotifyReason::Transformed` 明示通知は D 側に存在しないため撤回済み | `unity.d` の `njgSetPuppetScale`/`njgSetPuppetTranslation` を正として、必要な再描画契約は Node/Projectable 側で写経対応する |

## Unity Backend スタブ/ダミー解消タスク（unity_backend.cs）

Status: `[ ]` todo, `[>]` in progress, `[x]` done, `[?]` blocked.

| Status | Task ID | 対象 | 完了条件 |
| --- | --- | --- | --- |
| [x] | UBP001 | `RenderingBackend` の dynamic framebuffer 管理 (`dynamicFramebufferKeyUsesHandle`, `acquire`, `release`, `glDeleteFramebuffers`) | texture handle ベースで関連 framebuffer を追跡・解放できること |
| [x] | UBP002 | `drawDrawableElements` / `enqueueSpan` / `drawUploadedGeometry` / `renderScene` | no-op を廃止し、実際に draw packet 経路へ流せること |
| [x] | UBP003 | `RenderingBackend.issueBlendBarrier` | no-op を廃止し、`CommandExecutor.issueBlendBarrier` へ反映されること |
| [x] | UBP004 | OpenGL互換 API (`glGetShaderiv`, `glGetProgramiv`, `glDeleteShader` 等) | shader/program ハンドルに対して実状態検証/解放が動作すること |
| [x] | UBP005 | 動的ライブラリ解決 (`dlopen`, `dlsym`) | `NativeLibrary` 経由で実際に解決処理が行われること |
| [x] | UBP006 | SDL/window 互換 API (`SDL_GL_SetAttribute`, `queryWindowPixelSize`, `requireWindowHandle`) | 設定値保持・画面サイズ取得・window handle 取得が no-op/固定値でないこと |
| [x] | UBP007 | `sampleTex` | `Texture2D` の実サンプリング結果を返すこと（readable/unreadable双方の経路） |
| [x] | UBP008 | DirectX互換 API (`WinD3D12*`, `D3D12_ROOT_DESCRIPTOR_TABLE`) | 関数ポインタ解決/有効ポインタ返却を行うこと |
| [x] | UBP009 | `DirectXRuntime.ensureUploadBuffer` | no-op を廃止し staging バッファ容量確保が動作すること |
| [x] | UBP010 | 検証と再評価 | `rg` によるスタブ痕跡確認と `compat-unity_backend.md` 再生成で内容を更新すること |
| [x] | UBP011 | `createShader(string,string)` のソース互換対応 | 入力ソースを解析し、シェーダプロファイル（mask/present/uniform）を反映すること |
| [x] | UBP012 | `CommandExecutor.ensurePresentProgram` 実体化 | present 用 material/mesh を初期化し、`presentSceneToBackbuffer` で利用すること |
| [x] | UBP013 | 高度ブレンド能力の実装化 | `supportsAdvancedBlend*` 固定 false を廃止し、実行環境に応じた能力初期化を行うこと |
| [x] | UBP014 | `DirectXRuntime` 互換レイヤ拡張 | swapchain target/srv binding/upload/geometry pack/frame 管理を実体化し、互換実行経路を強化すること |

## Unity Plugin 拡張タスク（Editor運用観点）

Status: `[ ]` todo, `[>]` in progress, `[x]` done, `[?]` blocked.

| Status | Task ID | 方針 | 対象 | 完了条件 |
| --- | --- | --- | --- | --- |
| [x] | UPE001 | A | `NicxliveBehaviour` 常時描画化（`ExecuteAlways` / Edit Mode 更新） | Play を押さない状態でも対象描画ループが継続すること |
| [x] | UPE002 | A | `NicxliveBehaviour` の transform 連携（位置・スケール） | GameObject の位置/スケールを native puppet 変換へ反映できること |
| [x] | UPE003 | A | `NicxliveRenderer`/PInvoke のパラメータ API 実装 (`njgGetParameters`/`njgUpdateParameters`) | モデルパラメータ列挙と更新を managed 側から実行できること |
| [x] | UPE004 | B | Editor 拡張ファイル追加（CustomEditor） | モデルファイル/リソースを Inspector から選択して `PuppetPath` に反映できること |
| [x] | UPE005 | B | Editor でのパラメータ操作 UI | Inspector からパラメータ値を変更し、実モデルに反映できること |
| [x] | UPE006 | A+B | 再評価反映 (`compat-unity_plugin_impl.md`) | 追加観点の判定が全て `OK` になること |
