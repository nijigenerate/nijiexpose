#pragma once

#include "../render/common.hpp"
#include "../texture.hpp"
#include "../nodes/mask.hpp"

#include <map>
#include <memory>
#include <optional>
#include "commands.hpp"

#include <string>
#include <vector>

namespace nicxlive::core::render {

using ::nicxlive::core::nodes::BlendMode;
using ::nicxlive::core::nodes::Mat4;
using ::nicxlive::core::nodes::Vec2;
using ::nicxlive::core::nodes::Vec3;
using ::nicxlive::core::nodes::Vec4;
using ::nicxlive::core::nodes::PartDrawPacket;
using ::nicxlive::core::Rect;

struct TextureHandle {
    uint32_t id{0};
    int width{0};
    int height{0};
    int inChannels{0};
    int outChannels{0};
    bool stencil{false};
    std::vector<uint8_t> data{};
    ::nicxlive::core::Filtering filtering{::nicxlive::core::Filtering::Linear};
    ::nicxlive::core::Wrapping wrapping{::nicxlive::core::Wrapping::Clamp};
    float anisotropy{1.0f};
};

enum class TextureCommandKind {
    Create,
    Update,
    Params,
    Dispose,
};

struct TextureCommand {
    TextureCommandKind kind{TextureCommandKind::Create};
    uint32_t id{0};
    int width{0};
    int height{0};
    int inChannels{0};
    int outChannels{0};
    bool stencil{false};
    std::vector<uint8_t> data{};
    ::nicxlive::core::Filtering filtering{::nicxlive::core::Filtering::Linear};
    ::nicxlive::core::Wrapping wrapping{::nicxlive::core::Wrapping::Clamp};
    float anisotropy{1.0f};
};

class QueueRenderBackend : public RenderBackend {
public:
    void clear();
    void initializeDrawableResources() override;
    void bindDrawableVao() override;
    void createDrawableBuffers(RenderResourceHandle& outHandle) override;
    void disposeDrawableBuffers(RenderResourceHandle id) override;
    void uploadDrawableIndices(RenderResourceHandle id, const std::vector<uint16_t>& indices) override;
    void uploadSharedVertexBuffer(const ::nicxlive::core::common::Vec2Array& v) override;
    void uploadSharedUvBuffer(const ::nicxlive::core::common::Vec2Array& u) override;
    void uploadSharedDeformBuffer(const ::nicxlive::core::common::Vec2Array& d) override;
    void drawDrawableElements(RenderResourceHandle id, std::size_t count) override;
    void setDebugPointSize(float v) override;
    void setDebugLineWidth(float v) override;
    void uploadDebugBuffer(const std::vector<Vec3>& positions, const std::vector<uint16_t>& indices) override;
    void drawDebugPoints(const Vec4&, const Mat4&) override;
    void drawDebugLines(const Vec4&, const Mat4&) override;
    void beginMask(bool useStencil) override;
    void applyMask(const MaskApplyPacket& packet) override;
    void beginMaskContent() override;
    void endMask() override;
    void beginDynamicComposite(const ::nicxlive::core::DynamicCompositePass& pass) override;
    void endDynamicComposite(const ::nicxlive::core::DynamicCompositePass& pass) override;
    void destroyDynamicComposite(const std::shared_ptr<::nicxlive::core::DynamicCompositeSurface>&) override;
    void drawPartPacket(const PartDrawPacket& packet) override;
    void resizeViewportTargets(int width, int height) override;
    void dumpViewport(std::vector<uint8_t>& dumpTo, int width, int height) override;
    RenderResourceHandle renderImageHandle() override;
    RenderResourceHandle framebufferHandle() override;
    RenderResourceHandle mainAlbedoHandle() override;
    RenderResourceHandle mainEmissiveHandle() override;
    RenderResourceHandle mainBumpHandle() override;
    RenderResourceHandle blendFramebufferHandle() override;
    RenderResourceHandle blendAlbedoHandle() override;
    RenderResourceHandle blendEmissiveHandle() override;
    RenderResourceHandle blendBumpHandle() override;
    void drawTextureAtPart(const Texture&, const std::shared_ptr<::nicxlive::core::nodes::Part>&) override;
    void drawTextureAtPosition(const Texture&, const Vec2&, float, const Vec3&, const Vec3&) override;
    void drawTextureAtRect(const Texture&, const Rect&, const Rect&, float, const Vec3&, const Vec3&, void*, void*) override;
    void setDifferenceAggregationEnabled(bool enabled) override;
    bool isDifferenceAggregationEnabled() override;
    void setDifferenceAggregationRegion(const DifferenceEvaluationRegion& region) override;
    DifferenceEvaluationRegion getDifferenceAggregationRegion() override;
    bool evaluateDifferenceAggregation(RenderResourceHandle, int, int) override;
    bool fetchDifferenceAggregationResult(DifferenceEvaluationResult& out) override;

    uint32_t createTexture(const std::vector<uint8_t>& data, int width, int height, int channels, bool stencil) override;
    void updateTexture(uint32_t id, const std::vector<uint8_t>& data, int width, int height, int channels) override;
    void setTextureParams(uint32_t id, ::nicxlive::core::Filtering filtering, ::nicxlive::core::Wrapping wrapping, float anisotropy) override;
    void disposeTexture(uint32_t id) override;
    bool hasTexture(uint32_t id) const;
    const TextureHandle* getTexture(uint32_t id) const;
    // Unity DLL 側に受け渡すためのコピー出力
    std::vector<QueuedCommand> queue{};
    std::vector<TextureCommand> resourceQueue{};

    // キューを別 backend に再生（D: RenderingBackend.playback 相当）
    void setRenderTargets(std::size_t renderHandle, std::size_t compositeHandle) {
        renderTargetHandle = renderHandle;
        compositeTargetHandle = compositeHandle;
    }

    const std::vector<uint16_t>* getDrawableIndices(uint32_t id) const {
        auto it = indexBuffers.find(id);
        if (it == indexBuffers.end()) return nullptr;
        return &it->second;
    }
    bool hasDrawableIndices(uint32_t id) const {
        return indexBuffers.find(id) != indexBuffers.end();
    }
    std::size_t drawableIndexBufferCount() const {
        return indexBuffers.size();
    }

private:
    uint32_t nextId{1};
    RenderResourceHandle nextIndexId{1};
    std::map<uint32_t, TextureHandle> textures{};
    std::map<RenderResourceHandle, std::vector<uint16_t>> indexBuffers{};
    ::nicxlive::core::common::Vec2Array sharedVertices{};
    ::nicxlive::core::common::Vec2Array sharedUvs{};
    ::nicxlive::core::common::Vec2Array sharedDeform{};
    std::vector<Vec3> debugPositions{};
    std::vector<uint16_t> debugIndices{};
    std::map<RenderResourceHandle, std::size_t> lastDraw{};
    float debugPointSize{1.0f};
    float debugLineWidth{1.0f};
    std::vector<MaskApplyPacket> maskPackets{};
    std::vector<::nicxlive::core::DynamicCompositePass> dynamicStack{};
    std::optional<::nicxlive::core::DynamicCompositePass> lastDynamic{};
    bool differenceAggregationEnabled{false};
    DifferenceEvaluationRegion differenceRegion{};
    DifferenceEvaluationResult differenceResult{};
    std::size_t renderTargetHandle{0};
    std::size_t compositeTargetHandle{0};
};

} // namespace nicxlive::core::render
